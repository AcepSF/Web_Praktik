from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask_mysqldb import MySQL, MySQLdb
from flask_session import Session
from datetime import datetime,  timedelta

app = Flask(__name__)

app.secret_key = "!@#$%"
session_duration = timedelta(seconds=3)

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] =  ''
app.config['MYSQL_DB'] = 'ecommerce'

mysql = MySQL(app)

app.config['SECRET_KEY'] = 'secret-key'
app.config['SESSION_TYPE'] = 'filesystem'


@app.route("/")
def index():            
    if "is_logged_in" in session and session["is_logged_in"]:
        cur = mysql.connection.cursor()

        cur.execute("SELECT * FROM pengguna")

        data = cur.fetchall()

        cur.close()

        return render_template("index.html", pengguna=data)
    else:
        return redirect(url_for("login"))


@app.route("/register", methods = ["GET", "POST"])
def register():
    if request.method == "POST":
        nama = request.form['nama']
        email = request.form['email']
        password = request.form['password']

        cur = mysql.connection.cursor()

        cur.execute("INSERT INTO pengguna VALUES (NULL, %s, %s, %s)", (nama, password, email))

        mysql.connection.commit()
        cur.close()

        return redirect(url_for('index'))
    else:
        return render_template("register.html")

@app.route('/login', methods =['GET', 'POST'])
def login():
    if request.method =='POST' and 'email'in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']

        cur = mysql.connection.cursor()

        cur.execute('SELECT * FROM pengguna WHERE email = %s and password = %s', (email, password))

        result = cur.fetchone()
        if result:
            session['is_logged_in'] = True
            session['username'] = result[1]

            session['last_activity'] = datetime.now()
            session.permanent = True
            app.permament_session_lifetime = timedelta(minutes=3)

            return redirect(url_for('index'))
        
        else:
            return render_template('login')
        
    return render_template('login.html')


@app.route('/logout')
def logout():
    session.pop("is_logged_in", None)
    session.pop("username", None)

    return redirect(url_for("login"))

@app.route("/index")
def home():
    if "is_logged_in" in session and session["is_logged_in"]:
        return render_template("index.html")
    else:
        return redirect(url_for("login"))
    
@app.route("/about")
def about():
    if "is_logged_in" in session and session["is_logged_in"]:
        return render_template("about.html")
    else:
        return redirect(url_for("login"))

@app.route("/kontak")
def kontak():
    if "is_logged_in" in session and session["is_logged_in"]:
        return render_template("kontak.html")
    else:
        return redirect(url_for("login"))

@app.route("/produk")
def produk():
    if "is_logged_in" in session and session["is_logged_in"]:
        return render_template("produk.html")
    else:
        return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(debug=True)