function submitForm(event) {
    event.preventDefault();
    alert('Message has been delivered!');
  }
  
  var form = document.querySelector('form');
  form.addEventListener('submit', submitForm);